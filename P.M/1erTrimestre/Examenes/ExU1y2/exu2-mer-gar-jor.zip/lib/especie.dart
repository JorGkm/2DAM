
class Especie {
  String nombreComun;
  final String? _nombreCientifico;
  double? pesoPromedio;
  bool? enPeligro;
  List<String>? dieta;
  Especie({
    required this.nombreComun,
    this._nombreCientifico,
    this.pesoPromedio,
    this.enPeligro,
    this.dieta,
  });
  String? get nombreCientifico => _nombreCientifico;
  //Aviso: debo recordar cambiar enPeligro por "Si" o "No"
  @override
  String toString() =>
      "Especie(\n\tNombre Común: $nombreComun\n\tNombre Científico: $_nombreCientifico\n\tPeso Promedio: $pesoPromedio Kg\n\tEn Peligro de Extinción: $enPeligro\n\tDieta: $dieta\n)";

  //METDOO COPYWITH
  Especie copyWith({
    String? nombreComun,
    String? nombreCientifico,
    double? pesoPromedio,
    bool? enPeligro,
    List<String>? dieta,
  }) => Especie(
    nombreComun: nombreComun ?? this.nombreComun,
    nombreCientifico: nombreCientifico ?? _nombreCientifico,
    pesoPromedio: pesoPromedio ?? this.pesoPromedio,
    enPeligro: enPeligro ?? this.enPeligro,
    dieta: dieta ?? List.from([this.dieta]),
  );
  //METODO TOJSON
  Map<String, dynamic> toJson() => {
    "nombreComun": nombreComun,
    if (_nombreCientifico != null) "nombreCientifico": _nombreCientifico,
    if (pesoPromedio != null) "pesoPromedio": pesoPromedio,
    if (enPeligro != null) "enPeligro": enPeligro,
    if (dieta != null) "dieta": dieta,
  };
  //METODO FROMJSON
  factory Especie.fromJson(Map<String, dynamic> datosJson) => Especie(
    nombreComun: datosJson["nombreComun"],
    nombreCientifico: datosJson["nombreCientifico"],
    pesoPromedio: datosJson["pesoPromedio"],
    enPeligro: datosJson["enPeligro"],
    dieta: datosJson["dieta"] ?? [],
  );
}
