import 'dart:convert';
import 'dart:io';

import 'package:exu2_mer_gar_jor/especie.dart';

void ejercicio1() {
  print("--- Crear especie 1 ---");
  var especie1 = Especie(
    nombreComun: "Panda Gigante",
    nombreCientifico: "Ailuropoda melanoleuca",
    pesoPromedio: 100,
    enPeligro: true,
    dieta: ["Bambú", "Frutas"]
  );
  print(especie1);
  print("--- Crear especie 2 copia ---");
  /*Al no haber programado los set ni nada no podemos añadir aparte de los que ya hay creado 
  por eso lo añado en el copyWith, ya que sino, no podemos acceder a ellos luego por problemas de nulabilidad
  */
  var especie2 = especie1.copyWith(pesoPromedio: 110, dieta: ["Bambú", "Frutas, Hortalizas"]);
  print(especie2);
  print("--- Mostrar especie 2 en JSON ---");
  print(jsonEncode(especie2.toJson()));
  print("--- Mostrar leon del leon.json ---");
  //Ponemos la ruta del archivo
  final rutaLeonJson = "/data/leon.json";
  //Instanciamos un file con dicha ruta
  final leonJson = File(rutaLeonJson);
  //Recogemos los datos de dicho archivo para guardarlos en una cadena
  final leonJsonString = leonJson.readAsString();
  //Decodificamos la cadena del formato json a un mapa
  Map<String, dynamic> datosMapaLeon = jsonDecode(leonJsonString.toString());
  //Dicho mapa lo usaremos para procesar los datos del json y construir una especie (leon)
  var leon = Especie.fromJson(datosMapaLeon);
  print(leon);
}
